# INSTRUÇÕES PARA O GITHUB (Entrega 2 - IFPE)

Este arquivo contém tudo que você precisa fazer no GitHub para atender aos requisitos do professor.

---

## 1. README.md (Página Inicial)

O `README.md` já foi atualizado com:
- Descrição completa do projeto
- Nomes e funções de todos os membros da equipe (Vinícius Valentim, Mateus Felix, Lucas Oliveira, Jader Albuquerque)

**Não altere** essa parte.

---

## 2. Criar as Issues (Backlog do Produto)

Vá em: **Issues → New issue**

Crie **uma Issue para cada HU** abaixo.  
Copie e cole o título + descrição.

### HU01 – Cadastro de Pacientes
**Título:** HU01 – Cadastro de Pacientes

**Descrição:**
```
Como recepcionista da clínica, eu quero cadastrar novos pacientes com seus dados pessoais e preferências de comunicação (Libras), para que eu possa atendê-los de forma adequada.

**Critérios de Aceitação:**
- [ ] Formulário de cadastro com campos: nome, CPF, data de nascimento, telefone, email, endereço, grau de surdez, prefere Libras, necessita intérprete, observações.
- [ ] Validação de CPF único
- [ ] CRUD completo (Create, Read, Update, Delete)
- [ ] Listagem de pacientes em tabela bonita
```

---

### HU02 – Agendamento de Consultas
**Título:** HU02 – Agendamento de Consultas

**Descrição:**
```
Como recepcionista, eu quero agendar consultas informando paciente, profissional, data/hora e intérprete (quando necessário), para organizar a agenda da clínica.

**Critérios de Aceitação:**
- [ ] Formulário com selects de Paciente, Profissional e Intérprete (opcional)
- [ ] Campo de data/hora e duração
- [ ] Status inicial = "agendada"
- [ ] CRUD completo de consultas
```

---

### HU03 – Histórico Médico
**Título:** HU03 – Histórico Médico

**Descrição:**
```
Como profissional de saúde, eu quero visualizar o histórico de consultas de um paciente, para tomar decisões clínicas mais assertivas.

**Critérios de Aceitação:**
- [ ] Página de Prontuário Eletrônico
- [ ] Lista de todas as consultas passadas do paciente
- [ ] Exibição de observações/registrados de atendimentos anteriores
```

---

### HU04 – Intérprete de Libras
**Título:** HU04 – Intérprete de Libras

**Descrição:**
```
Como recepcionista, eu quero cadastrar e gerenciar intérpretes de Libras, para poder alocá-los nas consultas quando necessário.

**Critérios de Aceitação:**
- [ ] CRUD completo de Intérpretes
- [ ] Campos: nome, telefone, email, nível de certificação, disponibilidade
- [ ] Seleção de intérprete ao agendar consulta
```

---

### HU05 – Notificações de Consulta
**Título:** HU05 – Notificações de Consulta

**Descrição:**
```
Como recepcionista, eu quero visualizar as próximas consultas agendadas (próximos dias), para poder confirmar ou se preparar para os atendimentos.

**Critérios de Aceitação:**
- [ ] Dashboard de consultas mostra alertas/notificações das próximas consultas (próximos 3 dias)
- [ ] Status coloridos (agendada, confirmada, realizada, cancelada)
```

---

### HU06 – Gestão de Profissionais
**Título:** HU06 – Gestão de Profissionais

**Descrição:**
```
Como administrador, eu quero cadastrar e gerenciar os profissionais da clínica (médicos, fonoaudiólogos, psicólogos etc).

**Critérios de Aceitação:**
- [ ] CRUD completo de Profissionais
- [ ] Campo de senha para login
- [ ] Listagem com especialidade e status (ativo/inativo)
```

---

### HU07 – Login no Sistema
**Título:** HU07 – Login no Sistema

**Descrição:**
```
Como usuário do sistema, eu quero fazer login com email e senha para acessar as funcionalidades protegidas da clínica.

**Critérios de Aceitação:**
- [ ] Tela de login funcional
- [ ] Autenticação via sessão
- [ ] Login com admin@clinica.com / 123456 (demo)
- [ ] Login também funciona com profissionais cadastrados
- [ ] Proteção de rotas (middleware de autenticação)
```

---

### HU08 – Cancelamento de Consultas
**Título:** HU08 – Cancelamento de Consultas

**Descrição:**
```
Como recepcionista, eu quero cancelar uma consulta agendada quando necessário.

**Critérios de Aceitação:**
- [ ] Botão "Cancelar" na listagem de consultas
- [ ] Atualiza status para "cancelada"
- [ ] Adiciona informação de cancelamento nas observações
```

---

### HU09 – Registro de Atendimento
**Título:** HU09 – Registro de Atendimento

**Descrição:**
```
Como profissional, eu quero registrar as observações do atendimento realizado em uma consulta, para alimentar o prontuário do paciente.

**Critérios de Aceitação:**
- [ ] Campo "Observações / Registro de Atendimento" na edição da consulta
- [ ] Atualização salva no banco
- [ ] Visível posteriormente no Prontuário Eletrônico
```

---

### HU10 – Prontuário Eletrônico
**Título:** HU10 – Prontuário Eletrônico

**Descrição:**
```
Como profissional de saúde, eu quero acessar o prontuário eletrônico completo de um paciente (dados + histórico de consultas + anotações), para ter visão integral do caso.

**Critérios de Aceitação:**
- [ ] Página dedicada de Prontuário
- [ ] Exibe dados do paciente + todas as consultas anteriores com observações
- [ ] Acesso rápido a partir da listagem de pacientes ou consultas
```

---

## 3. Criar o Quadro Kanban (Sprint 01)

1. Vá na aba **Projects** do repositório
2. Clique em **New project**
3. Escolha o template **Kanban**
4. Nomeie como: **Sprint 01 - Clínica Acessível**
5. Crie as colunas (se não vierem prontas):
   - **Backlog da Sprint**
   - **To Do**
   - **Doing**
   - **Done**

6. Após criar as Issues, arraste as histórias que farão parte da Sprint 01 para a coluna **Backlog da Sprint**.

**Recomendação de Planning Poker (sugestão):**
- HU01, HU06, HU04, HU07 → 5 pontos (CRUDs mais complexos)
- HU02, HU10 → 8 pontos
- HU03, HU05, HU08, HU09 → 3 pontos

---

## 4. Fluxo de Desenvolvimento (Obrigatório - Pontuação Individual)

Cada desenvolvedor **deve** seguir este fluxo para cada história que for responsável:

1. **Criar uma branch a partir da Issue**
   ```bash
   git checkout -b feature/hu01-cadastro-pacientes
   ```

2. Desenvolver o CRUD completo da história.

3. Fazer commit(s) bem descritivos.

4. **Push** para o repositório remoto.

5. Abrir **Pull Request** (associando à Issue correspondente).

6. O **Scrum Master (Vinícius)** fará o code review e o **merge** para a `main`.

**Atenção:**
- Cada pessoa deve ficar responsável por **pelo menos um CRUD completo**.
- Não façam merge direto na main sem PR.
- Se uma tarefa depender de outra, avisem o Scrum Master para orientação de merge.

---

## 5. Envio Final

Após tudo configurado:

- Issues criadas
- README atualizado
- Código completo no repositório
- Quadro Kanban (Sprint 01) criado

**Enviar apenas o link do repositório no Classroom.**

---

Boa sorte na entrega!
Qualquer dúvida, me avise que eu ajudo a ajustar.

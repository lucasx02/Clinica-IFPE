-- =============================================
-- 03_consultas_select.sql
-- Exemplos de consultas úteis (SELECTs)
-- =============================================

-- 1. Listar todos os pacientes
SELECT * FROM pacientes ORDER BY nome;

-- 2. Próximas consultas (próximos 7 dias)
SELECT 
    c.id,
    p.nome AS paciente,
    pr.nome AS profissional,
    i.nome AS interprete,
    c.data_hora,
    c.status,
    c.motivo
FROM consultas c
JOIN pacientes p ON c.paciente_id = p.id
JOIN profissionais pr ON c.profissional_id = pr.id
LEFT JOIN interpretes i ON c.interprete_id = i.id
WHERE c.data_hora BETWEEN NOW() AND DATE_ADD(NOW(), INTERVAL 7 DAY)
  AND c.status IN ('agendada', 'confirmada')
ORDER BY c.data_hora;

-- 3. Histórico / Prontuário de um paciente específico (ex: id=1)
SELECT 
    c.data_hora,
    pr.nome AS profissional,
    i.nome AS interprete,
    c.status,
    c.motivo,
    c.observacoes
FROM consultas c
JOIN profissionais pr ON c.profissional_id = pr.id
LEFT JOIN interpretes i ON c.interprete_id = i.id
WHERE c.paciente_id = 1
ORDER BY c.data_hora DESC;

-- 4. Consultas por profissional
SELECT COUNT(*) AS total_consultas, pr.nome
FROM consultas c
JOIN profissionais pr ON c.profissional_id = pr.id
GROUP BY pr.id, pr.nome;

-- 5. Pacientes que precisam de intérprete
SELECT nome, grau_surdez, necessidade_interprete 
FROM pacientes 
WHERE necessidade_interprete = TRUE;

-- =============================================
-- 05_deletes.sql
-- Exemplos de exclusões (cuidado!)
-- =============================================

-- Excluir um paciente (cascade nas consultas)
-- DELETE FROM pacientes WHERE id = 99;

-- Excluir intérprete (set null nas consultas)
-- DELETE FROM interpretes WHERE id = 99;

-- Excluir profissional (bloqueado se tiver consultas)
-- DELETE FROM profissionais WHERE id = 99;

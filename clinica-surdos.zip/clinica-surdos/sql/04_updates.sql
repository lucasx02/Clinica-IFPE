-- =============================================
-- 04_updates.sql
-- Exemplos de atualizações
-- =============================================

-- Atualizar status de consulta para realizada + adicionar observação (HU09 e HU10)
UPDATE consultas 
SET 
    status = 'realizada',
    observacoes = 'Atendimento realizado com sucesso. Paciente demonstrou boa evolução. Recomendado retorno em 30 dias. Uso de Libras durante toda a consulta.'
WHERE id = 4;

-- Atualizar dados de paciente
UPDATE pacientes 
SET 
    telefone = '(81) 97777-9999',
    observacoes = 'Atualizado em 01/07/2026 - Novo endereço cadastrado.'
WHERE id = 1;

-- Cancelar uma consulta (HU08)
UPDATE consultas 
SET status = 'cancelada', 
    observacoes = CONCAT(COALESCE(observacoes, ''), ' | Cancelada em ', NOW())
WHERE id = 5;

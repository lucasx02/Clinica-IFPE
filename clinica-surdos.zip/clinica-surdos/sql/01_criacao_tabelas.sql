-- =============================================
-- 01_criacao_tabelas.sql
-- Criação das tabelas para Clínica de Surdos
-- Compatível com MySQL/MariaDB e PostgreSQL (com ajustes)
-- =============================================

-- Tabela de Pacientes
CREATE TABLE IF NOT EXISTS pacientes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(150) NOT NULL,
    cpf VARCHAR(14) UNIQUE NOT NULL,
    data_nascimento DATE NOT NULL,
    telefone VARCHAR(20),
    email VARCHAR(100) UNIQUE,
    endereco TEXT,
    grau_surdez ENUM('Leve', 'Moderada', 'Severa', 'Profunda') DEFAULT 'Moderada',
    prefere_libras BOOLEAN DEFAULT TRUE,
    necessidade_interprete BOOLEAN DEFAULT TRUE,
    observacoes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabela de Profissionais
CREATE TABLE IF NOT EXISTS profissionais (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(150) NOT NULL,
    especialidade VARCHAR(100) NOT NULL,
    registro_profissional VARCHAR(50) UNIQUE,
    telefone VARCHAR(20),
    email VARCHAR(100) UNIQUE NOT NULL,
    senha VARCHAR(255) NOT NULL,
    ativo BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabela de Intérpretes de Libras
CREATE TABLE IF NOT EXISTS interpretes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(150) NOT NULL,
    telefone VARCHAR(20),
    email VARCHAR(100) UNIQUE,
    nivel_certificacao ENUM('Básico', 'Intermediário', 'Avançado', 'Fluente') DEFAULT 'Intermediário',
    disponibilidade TEXT,
    observacoes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabela de Consultas
CREATE TABLE IF NOT EXISTS consultas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    paciente_id INT NOT NULL,
    profissional_id INT NOT NULL,
    interprete_id INT NULL,
    data_hora DATETIME NOT NULL,
    duracao_minutos INT DEFAULT 30,
    status ENUM('agendada', 'confirmada', 'realizada', 'cancelada') DEFAULT 'agendada',
    motivo TEXT,
    observacoes TEXT,  -- Campo para Registro de Atendimento / Prontuário
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (paciente_id) REFERENCES pacientes(id) ON DELETE CASCADE,
    FOREIGN KEY (profissional_id) REFERENCES profissionais(id) ON DELETE RESTRICT,
    FOREIGN KEY (interprete_id) REFERENCES interpretes(id) ON DELETE SET NULL
);

-- Índices para performance
CREATE INDEX idx_consultas_data ON consultas(data_hora);
CREATE INDEX idx_consultas_paciente ON consultas(paciente_id);
CREATE INDEX idx_consultas_status ON consultas(status);

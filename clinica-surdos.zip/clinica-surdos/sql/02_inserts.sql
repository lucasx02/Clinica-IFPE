-- =============================================
-- 02_inserts.sql
-- Dados de exemplo para testes
-- =============================================

-- Profissionais (senha = 123456 - hash bcrypt no app)
INSERT INTO profissionais (nome, especialidade, registro_profissional, telefone, email, senha, ativo) VALUES
('Dra. Ana Clara Mendes', 'Otorrinolaringologia', 'CRM-PE 12345', '(81) 99999-0001', 'ana.mendes@clinica.com', '$2a$10$examplehashfor123456', TRUE),
('Dr. Pedro Henrique Silva', 'Fonoaudiologia', 'CRFa 67890', '(81) 99999-0002', 'pedro.silva@clinica.com', '$2a$10$examplehashfor123456', TRUE),
('Dra. Laura Beatriz Costa', 'Psicologia', 'CRP 11223', '(81) 99999-0003', 'laura.costa@clinica.com', '$2a$10$examplehashfor123456', TRUE);

-- Intérpretes
INSERT INTO interpretes (nome, telefone, email, nivel_certificacao, disponibilidade) VALUES
('João Pedro Almeida', '(81) 98888-1111', 'joao.almeida@libras.com', 'Fluente', 'Segunda a Sexta - Manhã e Tarde'),
('Maria Eduarda Santos', '(81) 98888-2222', 'maria.santos@libras.com', 'Avançado', 'Segunda a Sábado - Integral'),
('Carlos Eduardo Lima', '(81) 98888-3333', 'carlos.lima@libras.com', 'Intermediário', 'Terça, Quinta e Sexta - Tarde');

-- Pacientes
INSERT INTO pacientes (nome, cpf, data_nascimento, telefone, email, endereco, grau_surdez, prefere_libras, necessidade_interprete, observacoes) VALUES
('Lucas Oliveira Santos', '123.456.789-00', '2010-05-15', '(81) 97777-0001', 'lucas.santos@email.com', 'Rua das Flores, 123 - Recife/PE', 'Severa', TRUE, TRUE, 'Aluno do IFPE. Prefere comunicação em Libras.'),
('Mateus Felix Souza', '234.567.890-11', '2008-11-22', '(81) 97777-0002', 'mateus.felix@email.com', 'Av. Caxangá, 456 - Recife/PE', 'Profunda', TRUE, TRUE, 'Necessita intérprete em todas as consultas.'),
('Jader Albuquerque Lima', '345.678.901-22', '2012-03-10', '(81) 97777-0003', NULL, 'Rua do Sol, 789 - Olinda/PE', 'Moderada', TRUE, FALSE, 'Consegue ler lábios razoavelmente.'),
('Vinícius Valentim Rocha', '456.789.012-33', '2005-07-30', '(81) 97777-0004', 'vini.valentim@email.com', 'Rua da Aurora, 321 - Recife/PE', 'Leve', FALSE, FALSE, 'Usa aparelho auditivo.');

-- Consultas de exemplo
INSERT INTO consultas (paciente_id, profissional_id, interprete_id, data_hora, status, motivo, observacoes) VALUES
(1, 1, 1, '2026-07-05 09:00:00', 'agendada', 'Avaliação otorrino de rotina e ajuste de aparelho', NULL),
(2, 2, 2, '2026-07-05 14:30:00', 'confirmada', 'Sessão de fonoaudiologia - exercícios de fala', 'Paciente evoluiu bem na última sessão.'),
(1, 3, NULL, '2026-07-10 10:00:00', 'agendada', 'Acompanhamento psicológico - apoio emocional', NULL),
(3, 1, 3, '2026-06-20 11:00:00', 'realizada', 'Consulta inicial - diagnóstico de grau de surdez', 'Exames realizados. Grau severo confirmado. Recomendado aparelho + Libras.'),
(4, 2, NULL, '2026-06-25 15:00:00', 'cancelada', 'Retorno fono - cancelado pelo paciente', 'Reagendar para próxima semana.');

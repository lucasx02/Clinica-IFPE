# Sistema de Gestão – Clínica Acessível (IFPE)

**Disciplina:** Desenvolvimento de Sistemas Web / Engenharia de Software  
**Instituição:** IFPE - Instituto Federal de Pernambuco

## Descrição do Projeto

Sistema web completo para gerenciamento de uma clínica especializada em atendimento a pacientes surdos.  
O sistema contempla:

- Cadastro e gestão de pacientes (com foco em acessibilidade em Libras)
- Gestão de profissionais de saúde
- Agendamento e controle de consultas
- Controle de intérpretes de Libras
- Prontuário eletrônico e histórico médico
- Notificações de consultas
- Cancelamento e registro de atendimentos

O objetivo é oferecer uma ferramenta acessível, moderna e funcional para facilitar o dia a dia da clínica e melhorar a experiência dos pacientes surdos.

## Equipe do Projeto

| Função              | Nome                    | Responsabilidade Principal      |
|---------------------|-------------------------|---------------------------------|
| **Scrum Master / Líder Técnico** | Vinícius Valentim      | Gestão do projeto, merges, arquitetura |
| Desenvolvedor       | Mateus Felix            | CRUDs e funcionalidades         |
| Desenvolvedor       | Lucas Oliveira          | CRUDs e funcionalidades         |
| Desenvolvedor       | Jader Albuquerque       | CRUDs e funcionalidades         |

---

## Tecnologias Utilizadas

- **Backend**: Node.js + TypeScript + Express
- **ORM**: Sequelize (SQLite por padrão)
- **Frontend**: Handlebars + Bootstrap 5
- **Autenticação**: Sessões + bcryptjs

## Backlog do Produto (User Stories)

Todas as histórias de usuário estão cadastradas como **Issues** no repositório (veja a aba Issues).

### Histórias de Usuário (HU01 a HU10)

- **HU01** – Cadastro de Pacientes
- **HU02** – Agendamento de Consultas
- **HU03** – Histórico Médico
- **HU04** – Intérprete de Libras
- **HU05** – Notificações de Consulta
- **HU06** – Gestão de Profissionais
- **HU07** – Login no Sistema
- **HU08** – Cancelamento de Consultas
- **HU09** – Registro de Atendimento
- **HU10** – Prontuário Eletrônico

---

## Como Executar o Projeto

### 1. Clone o repositório
```bash
git clone https://github.com/lucasx02/Clinica-IFPE.git
cd Clinica-IFPE
```

### 2. Instale as dependências
```bash
npm install
```

### 3. Execute o sistema
```bash
npm run dev
```

Acesse: **http://localhost:3000**

**Login padrão:**
- Email: `admin@clinica.com`
- Senha: `123456`

---

## Estrutura do Projeto

O projeto segue o padrão MVC com TypeScript:

```
src/
├── config/
├── models/
├── controllers/
├── routes/
├── views/          ← Handlebars (HTML)
└── public/         ← CSS + JS
```

Os scripts SQL estão na pasta `/sql/`.

---

## Sprint 01

- **Quadro Kanban**: GitHub Projects → Sprint 01
- **Backlog da Sprint**: Apenas as histórias priorizadas para esta entrega
- Cada desenvolvedor está atribuído a pelo menos uma história de **CRUD**

---

*Projeto desenvolvido como requisito da disciplina de IFPE - 2026*

## Tecnologias Utilizadas

- **Backend**: Node.js + TypeScript + Express
- **ORM**: Sequelize (com SQLite por padrão - fácil de usar)
- **Frontend**: Handlebars (HTML + CSS + JS)
- **Estilização**: Bootstrap 5 (via CDN) + CSS customizado
- **Autenticação**: Sessões + bcryptjs

## Histórias de Usuário Implementadas (HU01 a HU10)

Baseado nas histórias fornecidas:

- **HU01 – Cadastro de Pacientes**: CRUD completo de pacientes (incluindo preferência de comunicação e necessidade de intérprete).
- **HU02 – Agendamento de Consultas**: Formulário para agendar consultas com seleção de paciente, profissional e intérprete (opcional).
- **HU03 – Histórico Médico**: Visualização do histórico de consultas de um paciente no Prontuário.
- **HU04 – Intérprete de Libras**: CRUD de intérpretes + seleção ao agendar consulta.
- **HU05 – Notificações de Consulta**: Dashboard mostra próximas consultas agendadas (simulação de notificações).
- **HU06 – Gestão de Profissionais**: CRUD completo de profissionais da clínica.
- **HU07 – Login no Sistema**: Tela de login com sessão persistente. Login demo: admin@clinica.com / 123456
- **HU08 – Cancelamento de Consultas**: Botão para cancelar consultas na listagem (muda status para 'cancelada').
- **HU09 – Registro de Atendimento**: Ao visualizar/editar consulta, é possível registrar observações/notas do atendimento (prontuário).
- **HU10 – Prontuário Eletrônico**: Página dedicada para visualizar todos os dados do paciente + histórico completo de consultas e anotações.

## Como Executar o Projeto

### Pré-requisitos
- Node.js v18+ e npm
- (Opcional) MySQL/MariaDB se quiser usar em produção (veja .env)

### Passos

1. Clone o repositório ou baixe os arquivos.

2. Instale as dependências:
   ```bash
   npm install
   ```

3. Configure o ambiente (já vem pronto para SQLite):
   ```bash
   cp .env .env.local  # se quiser editar
   ```

4. Inicie o servidor em modo desenvolvimento (recomendado):
   ```bash
   npm run dev
   ```

   Ou build + start:
   ```bash
   npm run build
   npm start
   ```

5. Acesse no navegador: **http://localhost:3000**

6. Faça login com:
   - Email: `admin@clinica.com`
   - Senha: `123456`

### Comandos Úteis

```bash
# Sincronizar modelos com o banco (cria tabelas automaticamente)
npm run db:sync

# Popular com dados de exemplo (seed)
npm run db:seed
```

O seed e sync são chamados automaticamente no app.ts em desenvolvimento.

### Estrutura de Pastas

Veja o diagrama fornecido no início do projeto. Segue padrão MVC com TypeScript.

### Banco de Dados

- **Padrão**: SQLite (`database.sqlite` gerado automaticamente)
- **Alternativa MySQL**: Edite `.env`, instale `mysql2` e rode os scripts em `/sql/`

Os scripts SQL manuais estão em `/sql/` para referência (01_criacao_tabelas.sql etc).

### Funcionalidades Principais

- Menu lateral/navbar com acesso rápido a todas as seções
- Listagens com tabelas bonitas (Bootstrap)
- Formulários com validação básica no front (HTML5)
- Confirmação de exclusão/cancelamento via JS
- Status de consultas coloridos
- Prontuário visual amigável para pacientes surdos (ícones de Libras onde possível)

## Equipe Original (referência)

- Vinícius Valentim – Scrum Master
- Mateus Felix – Desenvolvedor
- Lucas Oliveira – Desenvolvedor
- Jader Albuquerque – Desenvolvedor

**Desenvolvido como projeto completo para a disciplina de IFPE - 2026**

## Observações Importantes

- Este é um sistema **demo/educacional**. Não use em produção sem adicionar mais validações, HTTPS, etc.
- Para produção com MySQL, rode os scripts SQL manualmente ou use migrations do Sequelize.
- O login é simples (sessão). Em produção use JWT + refresh ou OAuth.

Qualquer dúvida ou melhoria, abra uma issue!

Boa sorte com o projeto! 🎉

import { Request, Response } from 'express';
import Consulta from '../models/Consulta';
import Paciente from '../models/Paciente';
import Profissional from '../models/Profissional';
import Interprete from '../models/Interprete';
import { Op } from 'sequelize';

export class ConsultaController {
  // Listar consultas + Dashboard com notificações (HU05)
  static async index(req: Request, res: Response) {
    try {
      const consultas = await Consulta.findAll({
        include: [
          { model: Paciente, attributes: ['id', 'nome'] },
          { model: Profissional, attributes: ['id', 'nome', 'especialidade'] },
          { model: Interprete, attributes: ['id', 'nome'] },
        ],
        order: [['data_hora', 'ASC']],
      });

      // Próximas consultas para notificações (próximos 3 dias)
      const hoje = new Date();
      const proximas = consultas.filter(c => {
        const data = new Date(c.data_hora);
        const diffDias = (data.getTime() - hoje.getTime()) / (1000 * 3600 * 24);
        return diffDias >= 0 && diffDias <= 3 && (c.status === 'agendada' || c.status === 'confirmada');
      });

      res.render('consultas/index', { 
        title: 'Consultas e Agendamentos', 
        consultas,
        proximas,
        success: req.query.success,
        error: req.query.error 
      });
    } catch (error) {
      console.error(error);
      res.render('consultas/index', { title: 'Consultas', consultas: [], proximas: [], error: 'Erro ao carregar consultas.' });
    }
  }

  // Formulário de agendamento (HU02)
  static async create(req: Request, res: Response) {
    try {
      const [pacientes, profissionais, interpretes] = await Promise.all([
        Paciente.findAll({ order: [['nome', 'ASC']] }),
        Profissional.findAll({ where: { ativo: true }, order: [['nome', 'ASC']] }),
        Interprete.findAll({ order: [['nome', 'ASC']] }),
      ]);

      res.render('consultas/form', { 
        title: 'Agendar Nova Consulta', 
        consulta: null,
        pacientes,
        profissionais,
        interpretes,
        action: '/consultas',
        method: 'POST'
      });
    } catch (error) {
      res.redirect('/consultas?error=Erro ao carregar formulário.');
    }
  }

  // Salvar agendamento
  static async store(req: Request, res: Response) {
    try {
      const { paciente_id, profissional_id, interprete_id, data_hora, duracao_minutos, motivo } = req.body;

      await Consulta.create({
        paciente_id: parseInt(paciente_id),
        profissional_id: parseInt(profissional_id),
        interprete_id: interprete_id ? parseInt(interprete_id) : null,
        data_hora,
        duracao_minutos: parseInt(duracao_minutos) || 30,
        motivo,
        status: 'agendada',
      });

      res.redirect('/consultas?success=Consulta agendada com sucesso! (HU02)');
    } catch (error) {
      console.error(error);
      res.redirect('/consultas/novo?error=Erro ao agendar. Verifique os dados.');
    }
  }

  // Formulário de edição / Registro de Atendimento (HU09)
  static async edit(req: Request, res: Response) {
    try {
      const consulta = await Consulta.findByPk(req.params.id, {
        include: [
          { model: Paciente },
          { model: Profissional, attributes: { exclude: ['senha'] } },
          { model: Interprete },
        ],
      });

      if (!consulta) return res.redirect('/consultas?error=Consulta não encontrada.');

      const [pacientes, profissionais, interpretes] = await Promise.all([
        Paciente.findAll({ order: [['nome', 'ASC']] }),
        Profissional.findAll({ where: { ativo: true }, order: [['nome', 'ASC']] }),
        Interprete.findAll({ order: [['nome', 'ASC']] }),
      ]);

      res.render('consultas/form', { 
        title: 'Editar / Registrar Atendimento', 
        consulta,
        pacientes,
        profissionais,
        interpretes,
        action: `/consultas/${req.params.id}`,
        method: 'PUT'
      });
    } catch (error) {
      res.redirect('/consultas?error=Erro ao carregar consulta.');
    }
  }

  // Atualizar consulta + Registrar atendimento (HU09)
  static async update(req: Request, res: Response) {
    try {
      const consulta = await Consulta.findByPk(req.params.id);
      if (!consulta) return res.redirect('/consultas?error=Não encontrada.');

      const { 
        paciente_id, profissional_id, interprete_id, 
        data_hora, duracao_minutos, status, motivo, observacoes 
      } = req.body;

      await consulta.update({
        paciente_id: parseInt(paciente_id),
        profissional_id: parseInt(profissional_id),
        interprete_id: interprete_id ? parseInt(interprete_id) : null,
        data_hora,
        duracao_minutos: parseInt(duracao_minutos) || 30,
        status: status || 'agendada',
        motivo,
        observacoes, // Aqui é o Registro de Atendimento / Prontuário (HU09 e HU10)
      });

      res.redirect('/consultas?success=Consulta atualizada e atendimento registrado com sucesso!');
    } catch (error) {
      res.redirect(`/consultas/${req.params.id}/editar?error=Erro ao salvar.`);
    }
  }

  // Cancelar consulta (HU08)
  static async cancelar(req: Request, res: Response) {
    try {
      const consulta = await Consulta.findByPk(req.params.id);
      if (!consulta) return res.redirect('/consultas?error=Não encontrada.');

      await consulta.update({ 
        status: 'cancelada',
        observacoes: (consulta.observacoes || '') + ' | Cancelada via sistema em ' + new Date().toLocaleString('pt-BR')
      });

      res.redirect('/consultas?success=Consulta cancelada com sucesso! (HU08)');
    } catch (error) {
      res.redirect('/consultas?error=Erro ao cancelar.');
    }
  }

  // Excluir consulta
  static async destroy(req: Request, res: Response) {
    try {
      const consulta = await Consulta.findByPk(req.params.id);
      if (!consulta) return res.redirect('/consultas?error=Não encontrada.');
      await consulta.destroy();
      res.redirect('/consultas?success=Consulta excluída.');
    } catch (error) {
      res.redirect('/consultas?error=Erro ao excluir.');
    }
  }

  // Prontuário Eletrônico do Paciente (HU10 + HU03)
  static async prontuario(req: Request, res: Response) {
    try {
      const pacienteId = req.params.pacienteId || req.query.paciente_id;
      
      if (!pacienteId) {
        // Lista pacientes para escolher
        const pacientes = await Paciente.findAll({ order: [['nome', 'ASC']] });
        return res.render('consultas/prontuario', { 
          title: 'Prontuário Eletrônico', 
          paciente: null,
          consultas: [],
          pacientes 
        });
      }

      const paciente = await Paciente.findByPk(pacienteId);
      if (!paciente) return res.redirect('/consultas/prontuario?error=Paciente não encontrado.');

      const consultas = await Consulta.findAll({
        where: { paciente_id: pacienteId },
        include: [
          { model: Profissional, attributes: ['nome', 'especialidade'] },
          { model: Interprete, attributes: ['nome'] },
        ],
        order: [['data_hora', 'DESC']],
      });

      res.render('consultas/prontuario', { 
        title: `Prontuário de ${paciente.nome}`, 
        paciente,
        consultas,
        pacientes: [] // não precisa da lista
      });
    } catch (error) {
      console.error(error);
      res.redirect('/consultas?error=Erro ao carregar prontuário.');
    }
  }
}

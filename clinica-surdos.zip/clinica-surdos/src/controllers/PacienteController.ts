import { Request, Response } from 'express';
import Paciente from '../models/Paciente';
import { Op } from 'sequelize';

export class PacienteController {
  // Listar todos os pacientes (HU01)
  static async index(req: Request, res: Response) {
    try {
      const pacientes = await Paciente.findAll({
        order: [['nome', 'ASC']],
      });
      res.render('pacientes/index', { 
        title: 'Pacientes', 
        pacientes,
        success: req.query.success,
        error: req.query.error 
      });
    } catch (error) {
      console.error(error);
      res.status(500).render('pacientes/index', { 
        title: 'Pacientes', 
        pacientes: [], 
        error: 'Erro ao carregar pacientes.' 
      });
    }
  }

  // Formulário de cadastro
  static create(req: Request, res: Response) {
    res.render('pacientes/form', { 
      title: 'Novo Paciente', 
      paciente: null,
      action: '/pacientes',
      method: 'POST'
    });
  }

  // Salvar novo paciente
  static async store(req: Request, res: Response) {
    try {
      const { 
        nome, cpf, data_nascimento, telefone, email, 
        endereco, grau_surdez, prefere_libras, necessidade_interprete, observacoes 
      } = req.body;

      await Paciente.create({
        nome,
        cpf,
        data_nascimento,
        telefone,
        email: email || null,
        endereco,
        grau_surdez: grau_surdez || 'Moderada',
        prefere_libras: prefere_libras === 'on' || prefere_libras === true,
        necessidade_interprete: necessidade_interprete === 'on' || necessidade_interprete === true,
        observacoes,
      });

      res.redirect('/pacientes?success=Paciente cadastrado com sucesso!');
    } catch (error: any) {
      console.error(error);
      if (error.name === 'SequelizeUniqueConstraintError') {
        return res.redirect('/pacientes/novo?error=CPF ou Email já cadastrado.');
      }
      res.redirect('/pacientes/novo?error=Erro ao cadastrar paciente.');
    }
  }

  // Formulário de edição
  static async edit(req: Request, res: Response) {
    try {
      const paciente = await Paciente.findByPk(req.params.id);
      if (!paciente) {
        return res.redirect('/pacientes?error=Paciente não encontrado.');
      }
      res.render('pacientes/form', { 
        title: 'Editar Paciente', 
        paciente,
        action: `/pacientes/${req.params.id}`,
        method: 'PUT'
      });
    } catch (error) {
      res.redirect('/pacientes?error=Erro ao carregar paciente.');
    }
  }

  // Atualizar paciente
  static async update(req: Request, res: Response) {
    try {
      const paciente = await Paciente.findByPk(req.params.id);
      if (!paciente) {
        return res.redirect('/pacientes?error=Paciente não encontrado.');
      }

      const { 
        nome, cpf, data_nascimento, telefone, email, 
        endereco, grau_surdez, prefere_libras, necessidade_interprete, observacoes 
      } = req.body;

      await paciente.update({
        nome,
        cpf,
        data_nascimento,
        telefone,
        email: email || null,
        endereco,
        grau_surdez: grau_surdez || 'Moderada',
        prefere_libras: prefere_libras === 'on' || prefere_libras === true,
        necessidade_interprete: necessidade_interprete === 'on' || necessidade_interprete === true,
        observacoes,
      });

      res.redirect('/pacientes?success=Paciente atualizado com sucesso!');
    } catch (error) {
      res.redirect(`/pacientes/${req.params.id}/editar?error=Erro ao atualizar.`);
    }
  }

  // Excluir paciente
  static async destroy(req: Request, res: Response) {
    try {
      const paciente = await Paciente.findByPk(req.params.id);
      if (!paciente) {
        return res.redirect('/pacientes?error=Paciente não encontrado.');
      }
      await paciente.destroy();
      res.redirect('/pacientes?success=Paciente excluído com sucesso!');
    } catch (error) {
      res.redirect('/pacientes?error=Não foi possível excluir. Verifique se há consultas vinculadas.');
    }
  }

  // Busca simples (para uso futuro em prontuário)
  static async search(req: Request, res: Response) {
    try {
      const q = req.query.q as string || '';
      const pacientes = await Paciente.findAll({
        where: {
          [Op.or]: [
            { nome: { [Op.like]: `%${q}%` } },
            { cpf: { [Op.like]: `%${q}%` } },
          ],
        },
        limit: 20,
      });
      res.json(pacientes);
    } catch (error) {
      res.status(500).json({ error: 'Erro na busca' });
    }
  }
}

import { Request, Response } from 'express';
import Interprete from '../models/Interprete';

export class InterpreteController {
  static async index(req: Request, res: Response) {
    try {
      const interpretes = await Interprete.findAll({ order: [['nome', 'ASC']] });
      res.render('interpretes/index', { 
        title: 'Intérpretes de Libras', 
        interpretes,
        success: req.query.success,
        error: req.query.error 
      });
    } catch (error) {
      res.render('interpretes/index', { title: 'Intérpretes', interpretes: [], error: 'Erro ao carregar.' });
    }
  }

  static create(req: Request, res: Response) {
    res.render('interpretes/form', { 
      title: 'Novo Intérprete', 
      interprete: null,
      action: '/interpretes',
      method: 'POST'
    });
  }

  static async store(req: Request, res: Response) {
    try {
      const { nome, telefone, email, nivel_certificacao, disponibilidade, observacoes } = req.body;
      await Interprete.create({ nome, telefone, email, nivel_certificacao, disponibilidade, observacoes });
      res.redirect('/interpretes?success=Intérprete cadastrado com sucesso!');
    } catch (error: any) {
      if (error.name === 'SequelizeUniqueConstraintError') {
        return res.redirect('/interpretes/novo?error=Email já cadastrado.');
      }
      res.redirect('/interpretes/novo?error=Erro ao cadastrar.');
    }
  }

  static async edit(req: Request, res: Response) {
    try {
      const interprete = await Interprete.findByPk(req.params.id);
      if (!interprete) return res.redirect('/interpretes?error=Não encontrado.');
      res.render('interpretes/form', { 
        title: 'Editar Intérprete', 
        interprete,
        action: `/interpretes/${req.params.id}`,
        method: 'PUT'
      });
    } catch (error) {
      res.redirect('/interpretes?error=Erro ao carregar.');
    }
  }

  static async update(req: Request, res: Response) {
    try {
      const interprete = await Interprete.findByPk(req.params.id);
      if (!interprete) return res.redirect('/interpretes?error=Não encontrado.');
      const { nome, telefone, email, nivel_certificacao, disponibilidade, observacoes } = req.body;
      await interprete.update({ nome, telefone, email, nivel_certificacao, disponibilidade, observacoes });
      res.redirect('/interpretes?success=Intérprete atualizado com sucesso!');
    } catch (error) {
      res.redirect(`/interpretes/${req.params.id}/editar?error=Erro ao atualizar.`);
    }
  }

  static async destroy(req: Request, res: Response) {
    try {
      const interprete = await Interprete.findByPk(req.params.id);
      if (!interprete) return res.redirect('/interpretes?error=Não encontrado.');
      await interprete.destroy();
      res.redirect('/interpretes?success=Intérprete excluído com sucesso!');
    } catch (error) {
      res.redirect('/interpretes?error=Não foi possível excluir.');
    }
  }
}

import { Request, Response } from 'express';
import Profissional from '../models/Profissional';
import { Op } from 'sequelize';

export class ProfissionalController {
  static async index(req: Request, res: Response) {
    try {
      const profissionais = await Profissional.findAll({
        order: [['nome', 'ASC']],
        attributes: { exclude: ['senha'] } // Nunca enviar senha
      });
      res.render('profissionais/index', { 
        title: 'Profissionais', 
        profissionais,
        success: req.query.success,
        error: req.query.error 
      });
    } catch (error) {
      console.error(error);
      res.render('profissionais/index', { title: 'Profissionais', profissionais: [], error: 'Erro ao carregar.' });
    }
  }

  static create(req: Request, res: Response) {
    res.render('profissionais/form', { 
      title: 'Novo Profissional', 
      profissional: null,
      action: '/profissionais',
      method: 'POST'
    });
  }

  static async store(req: Request, res: Response) {
    try {
      const { nome, especialidade, registro_profissional, telefone, email, senha, ativo } = req.body;

      await Profissional.create({
        nome,
        especialidade,
        registro_profissional,
        telefone,
        email,
        senha: senha || '123456', // senha padrão
        ativo: ativo === 'on' || ativo === true || ativo === 'true',
      });

      res.redirect('/profissionais?success=Profissional cadastrado com sucesso!');
    } catch (error: any) {
      if (error.name === 'SequelizeUniqueConstraintError') {
        return res.redirect('/profissionais/novo?error=Email ou Registro já cadastrado.');
      }
      res.redirect('/profissionais/novo?error=Erro ao cadastrar profissional.');
    }
  }

  static async edit(req: Request, res: Response) {
    try {
      const profissional = await Profissional.findByPk(req.params.id, {
        attributes: { exclude: ['senha'] }
      });
      if (!profissional) return res.redirect('/profissionais?error=Não encontrado.');
      
      res.render('profissionais/form', { 
        title: 'Editar Profissional', 
        profissional,
        action: `/profissionais/${req.params.id}`,
        method: 'PUT'
      });
    } catch (error) {
      res.redirect('/profissionais?error=Erro ao carregar.');
    }
  }

  static async update(req: Request, res: Response) {
    try {
      const profissional = await Profissional.findByPk(req.params.id);
      if (!profissional) return res.redirect('/profissionais?error=Não encontrado.');

      const { nome, especialidade, registro_profissional, telefone, email, senha, ativo } = req.body;

      const updateData: any = {
        nome,
        especialidade,
        registro_profissional,
        telefone,
        email,
        ativo: ativo === 'on' || ativo === true || ativo === 'true',
      };

      if (senha && senha.trim() !== '') {
        updateData.senha = senha;
      }

      await profissional.update(updateData);
      res.redirect('/profissionais?success=Profissional atualizado com sucesso!');
    } catch (error) {
      res.redirect(`/profissionais/${req.params.id}/editar?error=Erro ao atualizar.`);
    }
  }

  static async destroy(req: Request, res: Response) {
    try {
      const profissional = await Profissional.findByPk(req.params.id);
      if (!profissional) return res.redirect('/profissionais?error=Não encontrado.');
      await profissional.destroy();
      res.redirect('/profissionais?success=Profissional excluído com sucesso!');
    } catch (error) {
      res.redirect('/profissionais?error=Não foi possível excluir (possui consultas vinculadas).');
    }
  }
}

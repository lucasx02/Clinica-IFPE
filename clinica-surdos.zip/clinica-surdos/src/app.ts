import express from 'express';
import path from 'path';
import { engine } from 'express-handlebars';
import session from 'express-session';
import methodOverride from 'method-override';
import dotenv from 'dotenv';
import sequelize from './config/database';
import Paciente from './models/Paciente';
import Profissional from './models/Profissional';
import Interprete from './models/Interprete';
import Consulta from './models/Consulta';
import routes from './routes/index';
import { loginUser, logoutUser } from './routes/auth';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

// ============================================
// Configuração do Handlebars
// ============================================
app.engine('handlebars', engine({
  defaultLayout: 'main',
  layoutsDir: path.join(__dirname, 'views', 'layouts'),
  partialsDir: path.join(__dirname, 'views', 'partials'),
  helpers: {
    // Helper para formatar data
    formatDate: (date: Date | string) => {
      if (!date) return '';
      const d = new Date(date);
      return d.toLocaleDateString('pt-BR') + ' ' + d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
    },
    // Status colorido
    statusClass: (status: string) => {
      switch (status) {
        case 'agendada': return 'badge bg-primary';
        case 'confirmada': return 'badge bg-info';
        case 'realizada': return 'badge bg-success';
        case 'cancelada': return 'badge bg-danger';
        default: return 'badge bg-secondary';
      }
    },
    // Helper para checked checkbox
    checked: (value: boolean) => value ? 'checked' : '',
    // Formatar data só data
    formatDateOnly: (date: Date | string) => {
      if (!date) return '';
      return new Date(date).toLocaleDateString('pt-BR');
    },
    eq: (a: any, b: any) => a == b,
    // Para select selected
    selected: (value: any, option: any) => value == option ? 'selected' : '',
    // Active class para menu (uso: {{activeMenu currentPath '/pacientes'}} )
    activeMenu: (currentPath: string, menuPath: string) => {
      if (!currentPath || !menuPath) return '';
      return currentPath.startsWith(menuPath) ? 'active' : '';
    },
  }
}));
app.set('view engine', 'handlebars');
app.set('views', path.join(__dirname, 'views'));

// ============================================
// Middlewares
// ============================================
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(methodOverride('_method')); // Permite PUT e DELETE via formulários
app.use(express.static(path.join(__dirname, '..', 'public')));

// Sessão
app.use(session({
  secret: process.env.SESSION_SECRET || 'clinicaSurdosSuperSecret2026',
  resave: false,
  saveUninitialized: false,
  cookie: { 
    maxAge: 1000 * 60 * 60 * 8, // 8 horas
    httpOnly: true 
  }
}));

// Variáveis globais para views (user logado)
app.use((req, res, next) => {
  res.locals.user = req.session.user || null;
  res.locals.currentPath = req.path;
  next();
});

// ============================================
// Rotas de Autenticação (HU07)
// ============================================
app.get('/login', (req, res) => {
  if (req.session.user) return res.redirect('/consultas');
  res.render('login', { 
    title: 'Login - Clínica Acessível',
    error: req.query.error,
    success: req.query.success 
  });
});

app.post('/login', async (req, res) => {
  const { email, senha } = req.body;

  // Login admin hardcoded (demo)
  if (email === process.env.ADMIN_EMAIL && senha === process.env.ADMIN_SENHA) {
    loginUser(req, { id: 0, nome: 'Administrador', email: email, tipo: 'admin' });
    return res.redirect('/consultas?success=Bem-vindo ao sistema!');
  }

  // Login com profissional
  try {
    const profissional = await Profissional.findOne({ where: { email } });
    if (profissional && await profissional.checkPassword(senha)) {
      loginUser(req, { 
        id: profissional.id, 
        nome: profissional.nome, 
        email: profissional.email, 
        tipo: 'profissional' 
      });
      return res.redirect('/consultas?success=Bem-vindo, ' + profissional.nome.split(' ')[0] + '!');
    }
  } catch (e) {
    console.error(e);
  }

  res.redirect('/login?error=Email ou senha incorretos.');
});

app.get('/logout', (req, res) => {
  logoutUser(req);
  res.redirect('/login?success=Você saiu do sistema.');
});

// ============================================
// Rotas principais (área logada)
// ============================================
app.use('/', routes);

// ============================================
// Rotas Públicas - Cliente (Autoatendimento)
// ============================================

// Página inicial bonita (Landing Page)
app.get('/', (req, res) => {
  if (req.session.user) {
    return res.redirect('/consultas');
  }
  res.render('home', { title: 'Clínica Acessível - Início' });
});

// Página pública para agendar consulta (cliente)
app.get('/agendar', (req, res) => {
  res.render('agendar', { title: 'Agendar Consulta - Clínica Acessível' });
});

// Receber solicitação de agendamento (público)
app.post('/agendar', async (req, res) => {
  try {
    const { nome_paciente, telefone, email, data_preferida, tipo_profissional, motivo, necessita_libras } = req.body;

    // Cria uma consulta com status "agendada" e observação de solicitação do paciente
    await Consulta.create({
      paciente_id: 1, // Usaremos paciente genérico por enquanto (melhoria futura: criar paciente automaticamente)
      profissional_id: 1,
      data_hora: data_preferida + ' 09:00:00',
      status: 'agendada',
      motivo: `[SOLICITAÇÃO ONLINE] ${motivo} | Tipo: ${tipo_profissional || 'Sem preferência'} | Necessita Libras: ${necessita_libras ? 'Sim' : 'Não'}`,
      observacoes: `Solicitação feita pelo paciente via site.\nNome: ${nome_paciente}\nTelefone: ${telefone}\nEmail: ${email || 'Não informado'}`
    });

    res.render('agendar', { 
      title: 'Agendamento Recebido',
      success: 'Solicitação enviada com sucesso! Nossa equipe entrará em contato em breve para confirmar.'
    });
  } catch (error) {
    console.error(error);
    res.render('agendar', { 
      title: 'Agendar Consulta',
      error: 'Ocorreu um erro ao enviar sua solicitação. Tente novamente.'
    });
  }
});

// 404
app.use((req, res) => {
  res.status(404).render('404', { title: 'Página não encontrada' });
});

// ============================================
// Sincronizar DB + Iniciar servidor
// ============================================
async function startServer() {
  try {
    // Definir associações (importante para includes)
    Paciente.hasMany(Consulta, { foreignKey: 'paciente_id', as: 'consultas' });
    Consulta.belongsTo(Paciente, { foreignKey: 'paciente_id', as: 'paciente' });

    Profissional.hasMany(Consulta, { foreignKey: 'profissional_id', as: 'consultas' });
    Consulta.belongsTo(Profissional, { foreignKey: 'profissional_id', as: 'profissional' });

    Interprete.hasMany(Consulta, { foreignKey: 'interprete_id', as: 'consultas' });
    Consulta.belongsTo(Interprete, { foreignKey: 'interprete_id', as: 'interprete' });

    // Sync models (cria tabelas se não existirem)
    await sequelize.sync({ alter: true }); // alter: true em dev (cuidado em prod)
    console.log('✅ Banco de dados sincronizado com sucesso!');

    // Seed inicial se não houver profissionais
    const countProf = await Profissional.count();
    if (countProf === 0) {
      console.log('🌱 Populando dados iniciais...');
      await seedInitialData();
    }

    app.listen(PORT, () => {
      console.log(`🚀 Servidor rodando em http://localhost:${PORT}`);
      console.log(`📋 Login: admin@clinica.com / 123456`);
    });
  } catch (error) {
    console.error('❌ Erro ao iniciar servidor:', error);
    process.exit(1);
  }
}

async function seedInitialData() {
  // Profissional admin/demo
  const prof = await Profissional.create({
    nome: 'Dra. Ana Clara Mendes',
    especialidade: 'Otorrinolaringologia',
    registro_profissional: 'CRM-PE 12345',
    telefone: '(81) 99999-0001',
    email: 'ana.mendes@clinica.com',
    senha: '123456',
    ativo: true,
  });

  await Interprete.create({
    nome: 'João Pedro Almeida',
    telefone: '(81) 98888-1111',
    email: 'joao.almeida@libras.com',
    nivel_certificacao: 'Fluente',
    disponibilidade: 'Segunda a Sexta - Manhã e Tarde',
  });

  await Paciente.create({
    nome: 'Lucas Oliveira Santos',
    cpf: '123.456.789-00',
    data_nascimento: '2010-05-15',
    telefone: '(81) 97777-0001',
    email: 'lucas.santos@email.com',
    endereco: 'Rua das Flores, 123 - Recife/PE',
    grau_surdez: 'Severa',
    prefere_libras: true,
    necessidade_interprete: true,
    observacoes: 'Aluno do IFPE. Prefere comunicação em Libras.',
  });

  console.log('✅ Seed inicial concluído!');
}

startServer();

export default app;

import { Model, DataTypes, Optional } from 'sequelize';
import sequelize from '../config/database';

interface ConsultaAttributes {
  id: number;
  paciente_id: number;
  profissional_id: number;
  interprete_id?: number | null;
  data_hora: Date;
  duracao_minutos: number;
  status: 'agendada' | 'confirmada' | 'realizada' | 'cancelada';
  motivo?: string;
  observacoes?: string;
  created_at?: Date;
  updated_at?: Date;
}

interface ConsultaCreationAttributes extends Optional<ConsultaAttributes, 'id' | 'created_at' | 'updated_at' | 'duracao_minutos' | 'status' | 'interprete_id'> {}

export class Consulta extends Model<ConsultaAttributes, ConsultaCreationAttributes> implements ConsultaAttributes {
  public id!: number;
  public paciente_id!: number;
  public profissional_id!: number;
  public interprete_id?: number | null;
  public data_hora!: Date;
  public duracao_minutos!: number;
  public status!: 'agendada' | 'confirmada' | 'realizada' | 'cancelada';
  public motivo?: string;
  public observacoes?: string;
  public readonly created_at!: Date;
  public readonly updated_at!: Date;

  // Associações populadas
  public paciente?: any;
  public profissional?: any;
  public interprete?: any;
}

Consulta.init(
  {
    id: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true,
    },
    paciente_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: { model: 'pacientes', key: 'id' },
    },
    profissional_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: { model: 'profissionais', key: 'id' },
    },
    interprete_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: { model: 'interpretes', key: 'id' },
    },
    data_hora: {
      type: DataTypes.DATE,
      allowNull: false,
    },
    duracao_minutos: {
      type: DataTypes.INTEGER,
      defaultValue: 30,
    },
    status: {
      type: DataTypes.ENUM('agendada', 'confirmada', 'realizada', 'cancelada'),
      defaultValue: 'agendada',
    },
    motivo: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    observacoes: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
  },
  {
    sequelize,
    modelName: 'Consulta',
    tableName: 'consultas',
    underscored: true,
  }
);

export default Consulta;

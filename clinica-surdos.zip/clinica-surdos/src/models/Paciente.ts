import { Model, DataTypes, Optional } from 'sequelize';
import sequelize from '../config/database';

interface PacienteAttributes {
  id: number;
  nome: string;
  cpf: string;
  data_nascimento: Date;
  telefone?: string;
  email?: string;
  endereco?: string;
  grau_surdez?: 'Leve' | 'Moderada' | 'Severa' | 'Profunda';
  prefere_libras: boolean;
  necessidade_interprete: boolean;
  observacoes?: string;
  created_at?: Date;
  updated_at?: Date;
}

interface PacienteCreationAttributes extends Optional<PacienteAttributes, 'id' | 'created_at' | 'updated_at'> {}

export class Paciente extends Model<PacienteAttributes, PacienteCreationAttributes> implements PacienteAttributes {
  public id!: number;
  public nome!: string;
  public cpf!: string;
  public data_nascimento!: Date;
  public telefone?: string;
  public email?: string;
  public endereco?: string;
  public grau_surdez?: 'Leve' | 'Moderada' | 'Severa' | 'Profunda';
  public prefere_libras!: boolean;
  public necessidade_interprete!: boolean;
  public observacoes?: string;
  public readonly created_at!: Date;
  public readonly updated_at!: Date;

  // Associações
  public consultas?: any[];
}

Paciente.init(
  {
    id: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true,
    },
    nome: {
      type: DataTypes.STRING(150),
      allowNull: false,
    },
    cpf: {
      type: DataTypes.STRING(14),
      allowNull: false,
      unique: true,
    },
    data_nascimento: {
      type: DataTypes.DATEONLY,
      allowNull: false,
    },
    telefone: {
      type: DataTypes.STRING(20),
      allowNull: true,
    },
    email: {
      type: DataTypes.STRING(100),
      allowNull: true,
      unique: true,
      validate: {
        isEmail: true,
      },
    },
    endereco: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    grau_surdez: {
      type: DataTypes.ENUM('Leve', 'Moderada', 'Severa', 'Profunda'),
      defaultValue: 'Moderada',
    },
    prefere_libras: {
      type: DataTypes.BOOLEAN,
      defaultValue: true,
    },
    necessidade_interprete: {
      type: DataTypes.BOOLEAN,
      defaultValue: true,
    },
    observacoes: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
  },
  {
    sequelize,
    modelName: 'Paciente',
    tableName: 'pacientes',
    underscored: true,
  }
);

export default Paciente;

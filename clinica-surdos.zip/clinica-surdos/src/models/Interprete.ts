import { Model, DataTypes, Optional } from 'sequelize';
import sequelize from '../config/database';

interface InterpreteAttributes {
  id: number;
  nome: string;
  telefone?: string;
  email?: string;
  nivel_certificacao?: 'Básico' | 'Intermediário' | 'Avançado' | 'Fluente';
  disponibilidade?: string;
  observacoes?: string;
  created_at?: Date;
  updated_at?: Date;
}

interface InterpreteCreationAttributes extends Optional<InterpreteAttributes, 'id' | 'created_at' | 'updated_at'> {}

export class Interprete extends Model<InterpreteAttributes, InterpreteCreationAttributes> implements InterpreteAttributes {
  public id!: number;
  public nome!: string;
  public telefone?: string;
  public email?: string;
  public nivel_certificacao?: 'Básico' | 'Intermediário' | 'Avançado' | 'Fluente';
  public disponibilidade?: string;
  public observacoes?: string;
  public readonly created_at!: Date;
  public readonly updated_at!: Date;

  public consultas?: any[];
}

Interprete.init(
  {
    id: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true,
    },
    nome: {
      type: DataTypes.STRING(150),
      allowNull: false,
    },
    telefone: {
      type: DataTypes.STRING(20),
      allowNull: true,
    },
    email: {
      type: DataTypes.STRING(100),
      allowNull: true,
      unique: true,
      validate: { isEmail: true },
    },
    nivel_certificacao: {
      type: DataTypes.ENUM('Básico', 'Intermediário', 'Avançado', 'Fluente'),
      defaultValue: 'Intermediário',
    },
    disponibilidade: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    observacoes: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
  },
  {
    sequelize,
    modelName: 'Interprete',
    tableName: 'interpretes',
    underscored: true,
  }
);

export default Interprete;

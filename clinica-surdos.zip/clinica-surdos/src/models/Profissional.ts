import { Model, DataTypes, Optional } from 'sequelize';
import sequelize from '../config/database';
import bcrypt from 'bcryptjs';

interface ProfissionalAttributes {
  id: number;
  nome: string;
  especialidade: string;
  registro_profissional?: string;
  telefone?: string;
  email: string;
  senha: string;
  ativo: boolean;
  created_at?: Date;
  updated_at?: Date;
}

interface ProfissionalCreationAttributes extends Optional<ProfissionalAttributes, 'id' | 'created_at' | 'updated_at' | 'ativo'> {}

export class Profissional extends Model<ProfissionalAttributes, ProfissionalCreationAttributes> implements ProfissionalAttributes {
  public id!: number;
  public nome!: string;
  public especialidade!: string;
  public registro_profissional?: string;
  public telefone?: string;
  public email!: string;
  public senha!: string;
  public ativo!: boolean;
  public readonly created_at!: Date;
  public readonly updated_at!: Date;

  public consultas?: any[];

  // Método para verificar senha
  public async checkPassword(senha: string): Promise<boolean> {
    return bcrypt.compare(senha, this.senha);
  }
}

Profissional.init(
  {
    id: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true,
    },
    nome: {
      type: DataTypes.STRING(150),
      allowNull: false,
    },
    especialidade: {
      type: DataTypes.STRING(100),
      allowNull: false,
    },
    registro_profissional: {
      type: DataTypes.STRING(50),
      allowNull: true,
      unique: true,
    },
    telefone: {
      type: DataTypes.STRING(20),
      allowNull: true,
    },
    email: {
      type: DataTypes.STRING(100),
      allowNull: false,
      unique: true,
      validate: { isEmail: true },
    },
    senha: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    ativo: {
      type: DataTypes.BOOLEAN,
      defaultValue: true,
    },
  },
  {
    sequelize,
    modelName: 'Profissional',
    tableName: 'profissionais',
    underscored: true,
    hooks: {
      beforeCreate: async (profissional: Profissional) => {
        if (profissional.senha) {
          profissional.senha = await bcrypt.hash(profissional.senha, 10);
        }
      },
      beforeUpdate: async (profissional: Profissional) => {
        if (profissional.changed('senha')) {
          profissional.senha = await bcrypt.hash(profissional.senha, 10);
        }
      },
    },
  }
);

export default Profissional;

import { Router } from 'express';
import { ProfissionalController } from '../controllers/ProfissionalController';
import { isAuthenticated } from './auth';

const router = Router();

router.use(isAuthenticated);

router.get('/', ProfissionalController.index);
router.get('/novo', ProfissionalController.create);
router.post('/', ProfissionalController.store);
router.get('/:id/editar', ProfissionalController.edit);
router.put('/:id', ProfissionalController.update);
router.delete('/:id', ProfissionalController.destroy);

export default router;

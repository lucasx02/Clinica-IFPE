import { Router } from 'express';
import { ConsultaController } from '../controllers/ConsultaController';
import { isAuthenticated } from './auth';

const router = Router();

router.use(isAuthenticated);

router.get('/', ConsultaController.index);
router.get('/novo', ConsultaController.create);
router.post('/', ConsultaController.store);
router.get('/:id/editar', ConsultaController.edit);
router.put('/:id', ConsultaController.update);
router.post('/:id/cancelar', ConsultaController.cancelar); // HU08
router.delete('/:id', ConsultaController.destroy);

// Prontuário Eletrônico (HU10)
router.get('/prontuario', ConsultaController.prontuario);
router.get('/prontuario/:pacienteId', ConsultaController.prontuario);

export default router;

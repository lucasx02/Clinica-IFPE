import { Router } from 'express';
import pacienteRoutes from './pacienteRoutes';
import profissionalRoutes from './profissionalRoutes';
import interpreteRoutes from './interpreteRoutes';
import consultaRoutes from './consultaRoutes';

const router = Router();

// Rotas principais
router.use('/pacientes', pacienteRoutes);
router.use('/profissionais', profissionalRoutes);
router.use('/interpretes', interpreteRoutes);
router.use('/consultas', consultaRoutes);

export default router;

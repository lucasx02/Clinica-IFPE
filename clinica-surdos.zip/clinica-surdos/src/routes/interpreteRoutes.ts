import { Router } from 'express';
import { InterpreteController } from '../controllers/InterpreteController';
import { isAuthenticated } from './auth';

const router = Router();

router.use(isAuthenticated);

router.get('/', InterpreteController.index);
router.get('/novo', InterpreteController.create);
router.post('/', InterpreteController.store);
router.get('/:id/editar', InterpreteController.edit);
router.put('/:id', InterpreteController.update);
router.delete('/:id', InterpreteController.destroy);

export default router;

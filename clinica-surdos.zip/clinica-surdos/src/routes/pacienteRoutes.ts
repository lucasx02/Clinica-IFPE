import { Router } from 'express';
import { PacienteController } from '../controllers/PacienteController';
import { isAuthenticated } from './auth'; // middleware de auth

const router = Router();

// Todas as rotas de paciente exigem login (HU07)
router.use(isAuthenticated);

router.get('/', PacienteController.index);
router.get('/novo', PacienteController.create);
router.post('/', PacienteController.store);
router.get('/:id/editar', PacienteController.edit);
router.put('/:id', PacienteController.update);
router.delete('/:id', PacienteController.destroy);
router.get('/busca', PacienteController.search);

export default router;

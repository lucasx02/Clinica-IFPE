import { Request, Response, NextFunction } from 'express';

declare module 'express-session' {
  interface SessionData {
    user?: {
      id: number;
      nome: string;
      email: string;
      tipo: string;
    };
    messages?: any;
  }
}

export function isAuthenticated(req: Request, res: Response, next: NextFunction) {
  if (req.session.user) {
    return next();
  }
  res.redirect('/login?error=Você precisa fazer login para acessar o sistema.');
}

export function loginUser(req: Request, user: any) {
  req.session.user = {
    id: user.id,
    nome: user.nome,
    email: user.email,
    tipo: 'profissional',
  };
}

export function logoutUser(req: Request) {
  req.session.destroy((err) => {
    if (err) console.error('Erro ao destruir sessão:', err);
  });
}

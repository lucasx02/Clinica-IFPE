import { Sequelize } from 'sequelize';
import dotenv from 'dotenv';

dotenv.config();

const dialect = (process.env.DB_DIALECT as 'sqlite' | 'mysql') || 'sqlite';

let sequelize: Sequelize;

if (dialect === 'sqlite') {
  sequelize = new Sequelize({
    dialect: 'sqlite',
    storage: process.env.DB_STORAGE || './database.sqlite',
    logging: false,
    define: {
      timestamps: true,
      underscored: true,
    },
  });
} else {
  // MySQL
  sequelize = new Sequelize(
    process.env.DB_NAME || 'clinica_surdos',
    process.env.DB_USER || 'root',
    process.env.DB_PASS || '',
    {
      host: process.env.DB_HOST || 'localhost',
      port: parseInt(process.env.DB_PORT || '3306'),
      dialect: 'mysql',
      logging: false,
      define: {
        timestamps: true,
        underscored: true,
      },
      dialectOptions: {
        charset: 'utf8mb4',
      },
    }
  );
}

export default sequelize;
